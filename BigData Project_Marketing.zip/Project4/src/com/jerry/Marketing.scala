package com.jerry

object Marketing extends App {
  
  import org.apache.spark._
  import org.apache.log4j._
  import org.apache.spark.sql._
  import org.apache.spark.sql.SparkSession
  import org.apache.spark.sql.types._
  import org.apache.spark.sql.functions._
  import org.apache.spark.ml.feature.StringIndexer

  Logger.getLogger("org").setLevel(Level.ERROR)
  
  val sc = new SparkContext("local[*]", "Marketing")
  val record = sc.textFile("C:/Users/JERRY/Documents/BDH_Project_1/Project4_dataset_bank-full2.csv")
  
  println("Number of Total Record:" + record.count())
  println("Sample Record:")
  record.take(6).foreach(println)
  val header = record.first
  val filtered = record.filter(x => x != header)
  
  println("After Removing Header: "+filtered.count())
  println("Sample Record:")
  filtered.take(6).foreach(println)
  
  val data = filtered.map(x => x.split(","))

  val rdds = data.map(x => Row(x(0).toInt, x(1),x(2),x(3),x(4), x(5).toInt,x(6),x(7),x(8), x(9).toInt,x(10),x(11).toInt,x(12).toInt, x(13).toInt,x(14).toInt,x(15),x(16)  ))
  val schema = StructType( List(StructField("age", IntegerType, true),StructField("job", StringType, true) ,StructField("marital", StringType, true),StructField("education", StringType, true) ,StructField("default", StringType, true),StructField("balance", IntegerType, true) ,StructField("housing", StringType, true) 	,StructField("loan", StringType, true) ,StructField("contact", StringType, true) ,StructField("day", IntegerType, true) ,StructField("month", StringType, true) ,StructField("duration", IntegerType, true) ,StructField("campaign", IntegerType, true) ,StructField("pdays", IntegerType, true) ,StructField("previous", IntegerType, true) ,StructField("poutcome", StringType, true) ,StructField("y", StringType, true)) )
  val spSession = SparkSession.builder().appName("Marketing").master("local[*]").getOrCreate()
  val df = spSession.createDataFrame(rdds,schema)
  df.show()
  
  val success_rate = (df.filter(df("y") === "yes").count()).toDouble / (df.count()).toDouble
  println("Success Rate:"+success_rate)

  //Give the maximum, mean, and minimum age of the average targeted customer
  df.select(max("age"),min("age"),mean("age")).show()
  
  //Check the quality of customers by checking average balance of customers
   df.select(mean("balance")).show()
   //Check the quality of customers by checking median balance of customers
   df.registerTempTable("datanewtable")
   spSession.sql("select percentile(balance, 0.50) from datanewtable").show()
   
   //Check if age matters in marketing subscription for deposit
   val ageSub = spSession.sql("select age, count(*) as number from datanewtable where y='yes' group by age order by number desc")
   ageSub.show()

   //Check if marital status mattered for a subscription to deposit
   val maritalSub = spSession.sql("select marital, count(*) as number from datanewtable where y='yes' group by marital order by number desc")
   maritalSub.show()
   
   //Check if age and marital status together mattered for a subscription to deposit scheme
   val ageandMaritalSub = spSession.sql("select age, marital, count(*) as number from datanewtable where y='yes' group by age,marital order by number desc")
   ageandMaritalSub.show()
   
   //Do feature engineering for the bank and find the right age effect on the campaign.
   //Replacing the old age column with the new age column
    
    val df_new = df.withColumn("age_cat", when(df("age") < 20 , "Teen").otherwise(when(df("age") <= 32, "Young").otherwise(when(df("age") <= 55 , "Mid_Age").otherwise("Old"))))
    df_new.show()

    df_new.registerTempTable("newdatatable")
    
    //which age group subscribed the most
    
    val targetage = spSession.sql("select age_cat, count(*) as number from newdatatable where y='yes' group by age_cat order by number desc")
    targetage.show()
    
    //pipelining with string Indexer
    
    val agedata2 = new StringIndexer().setInputCol("age_cat").setOutputCol("ageindex")
    
    //Fitting the model
    
    var strindModel = agedata2.fit(df_new)
    
    //assigns generated value of index of the column, by feature engineering
    
    strindModel.transform(df_new).select("age_cat","ageIndex").show(20)


  
}